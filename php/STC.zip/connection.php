<?php
    $dbhost = "localhost";
    $dbuser = "ytoovumw_bscs3a";
    $dbpass = "kaAGi]gz8H2*";
    $dbname = "ytoovumw_bscs3a";

    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
    if ($conn->connect_error) {
        echo $conn->connect_error;
    } 
?>